module.exports = {
  run : () => {
    // just our message to make when we are connected
    console.log("Bot connected...");
  }
}
