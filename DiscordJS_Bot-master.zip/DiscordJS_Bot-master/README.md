## Project moved to https://github.com/Kernelization/Bots/tree/master/%40diredan

## Installation

1) `git clone https://github.com/DireDan/DiscordJS_Bot.git`
2) `cd DiscordJS_Bot`
3) `npm install`
4) open up config.json, and replace the token with your bots token
5) `node index.js`
6) success!


## Credits
1) Discord.JS -> The Discord API Wrapper Used :D
